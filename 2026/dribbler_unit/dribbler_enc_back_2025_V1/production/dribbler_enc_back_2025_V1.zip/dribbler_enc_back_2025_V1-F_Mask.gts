G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,8.0.2*
G04 #@! TF.CreationDate,2024-11-14T19:32:42+09:00*
G04 #@! TF.ProjectId,dribbler_enc_back_2025_V1,64726962-626c-4657-925f-656e635f6261,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 8.0.2) date 2024-11-14 19:32:42*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.237500X-0.250000X-0.237500X0.250000X-0.237500X0.250000X0.237500X-0.250000X0.237500X0*%
%ADD11RoundRect,0.250000X0.707107X-0.353553X-0.353553X0.707107X-0.707107X0.353553X0.353553X-0.707107X0*%
%ADD12RoundRect,0.237500X0.287500X0.237500X-0.287500X0.237500X-0.287500X-0.237500X0.287500X-0.237500X0*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,R2*
X156087500Y-100200000D03*
X157912500Y-100200000D03*
G04 #@! TD*
G04 #@! TO.C,R1*
X156087500Y-108000000D03*
X157912500Y-108000000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,J1*
X163501974Y-109298026D03*
X165298026Y-107501974D03*
G04 #@! TD*
D12*
G04 #@! TO.C,D1*
X161275000Y-108000000D03*
X159525000Y-108000000D03*
G04 #@! TD*
G04 #@! TO.C,D2*
X161275000Y-100200000D03*
X159525000Y-100200000D03*
G04 #@! TD*
M02*
