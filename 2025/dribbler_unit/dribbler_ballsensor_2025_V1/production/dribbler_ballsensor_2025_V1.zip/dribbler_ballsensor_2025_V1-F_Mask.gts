G04 #@! TF.GenerationSoftware,KiCad,Pcbnew,8.0.7*
G04 #@! TF.CreationDate,2025-01-15T17:04:40+09:00*
G04 #@! TF.ProjectId,dribbler_ballsensor_2025_V1,64726962-626c-4657-925f-62616c6c7365,rev?*
G04 #@! TF.SameCoordinates,Original*
G04 #@! TF.FileFunction,Soldermask,Top*
G04 #@! TF.FilePolarity,Negative*
%FSLAX46Y46*%
G04 Gerber Fmt 4.6, Leading zero omitted, Abs format (unit mm)*
G04 Created by KiCad (PCBNEW 8.0.7) date 2025-01-15 17:04:40*
%MOMM*%
%LPD*%
G01*
G04 APERTURE LIST*
G04 Aperture macros list*
%AMRoundRect*
0 Rectangle with rounded corners*
0 $1 Rounding radius*
0 $2 $3 $4 $5 $6 $7 $8 $9 X,Y pos of 4 corners*
0 Add a 4 corners polygon primitive as box body*
4,1,4,$2,$3,$4,$5,$6,$7,$8,$9,$2,$3,0*
0 Add four circle primitives for the rounded corners*
1,1,$1+$1,$2,$3*
1,1,$1+$1,$4,$5*
1,1,$1+$1,$6,$7*
1,1,$1+$1,$8,$9*
0 Add four rect primitives between the rounded corners*
20,1,$1+$1,$2,$3,$4,$5,0*
20,1,$1+$1,$4,$5,$6,$7,0*
20,1,$1+$1,$6,$7,$8,$9,0*
20,1,$1+$1,$8,$9,$2,$3,0*%
G04 Aperture macros list end*
%ADD10RoundRect,0.250000X-0.750000X-0.250000X0.750000X-0.250000X0.750000X0.250000X-0.750000X0.250000X0*%
%ADD11RoundRect,0.237500X-0.250000X-0.237500X0.250000X-0.237500X0.250000X0.237500X-0.250000X0.237500X0*%
%ADD12C,5.000000*%
%ADD13C,1.800000*%
%ADD14R,1.800000X1.800000*%
G04 APERTURE END LIST*
D10*
G04 #@! TO.C,J2*
X-22500000Y19230000D03*
X-22500000Y21770000D03*
G04 #@! TD*
D11*
G04 #@! TO.C,R6*
X-13912500Y20000000D03*
X-12087500Y20000000D03*
G04 #@! TD*
G04 #@! TO.C,R1*
X-18412500Y23500000D03*
X-16587500Y23500000D03*
G04 #@! TD*
G04 #@! TO.C,R2*
X-18412500Y22000000D03*
X-16587500Y22000000D03*
G04 #@! TD*
D10*
G04 #@! TO.C,J1*
X-22500000Y51230000D03*
X-22500000Y53770000D03*
G04 #@! TD*
D12*
G04 #@! TO.C,REF\u002A\u002A*
X-18200000Y29533036D03*
G04 #@! TD*
G04 #@! TO.C,REF\u002A\u002A*
X-3000000Y2933036D03*
G04 #@! TD*
D13*
G04 #@! TO.C,D1*
X-1730000Y10933036D03*
D14*
X-4270000Y10933036D03*
G04 #@! TD*
D12*
G04 #@! TO.C,REF\u002A\u002A*
X-3000000Y19052200D03*
G04 #@! TD*
M02*
